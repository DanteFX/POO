//Inicio 9:50am; Finalizado 9:56am

//definición de clase {public Practica01(){

public class Practica02 {// extends Parent implements Interface {

  //{atributos}*
  private String saludo = "Hola Mundo";
  public float presupuesto;
  static int color = 5;
  protected boolean active;

  //{metodos}*

  public String getSaludo(){
    return saludo;

  }

}
//}fin de definición de la clase
